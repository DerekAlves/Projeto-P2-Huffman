# Projeto-P2-Huffman
Projeto para Estrutura de Dados (Huffman).
Universidade Federal de Alagoas - Instituto de Computação.
ECOM-008 - Estrutura de Dados.

Derek Nielsen Araújo Alves;
Darlysson Olímpio Nascimento;
Aldemir Melo Rocha Filho;
Yuri Fernandes Souza Silva;
Walmer Almeida Cavalcante.

Inicio em:
10 de Setembro de 2018, Maceió - AL, Brasil.
